//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Stoplite.rc
//
#define IDS_STOPLITE                    1
#define IDD_ABOUTBOX_STOPLITE           1
#define IDB_STOPLITE                    1
#define IDI_ABOUTDLL                    1
#define IDS_STOPLITE_PPG                2
#define IDS_STOPLITE_PPG_CAPTION        100
#define IDD_PROPPAGE_STOPLITE           100
#define IDC_COLORGROUP                  202
#define IDC_OFF                         203
#define IDC_RED                         204
#define IDC_GREEN                       205
#define IDC_YELLOW                      206
#define IDC_TESTALL                     207

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        201
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         204
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
