//#define DEBUG               // when defined, screen is half-size
                            // for sharing memory with IDE


void Putico(int X, int Y, ICON ico);

