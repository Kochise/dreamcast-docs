#include "stdafx.h"

#ifdef _WINDLL
     // Library init
	class CAfxDLL : public CWinApp
	{
	public:
		virtual BOOL InitInstance(); // Initialization
		virtual int ExitInstance();  // Termination
	     CAfxDLL(const char* pszAppName)
			: CWinApp(pszAppName)
			{ }
	};
	
	BOOL CAfxDLL::InitInstance()
	{
		return TRUE;
	}
	
	int CAfxDLL::ExitInstance()
	{
		return CWinApp::ExitInstance();
	}
	
	CAfxDLL NEAR afxDLL(NULL); // use AFX_IDS_APP_TITLE for application title

#endif //ifndef _WINDLL

