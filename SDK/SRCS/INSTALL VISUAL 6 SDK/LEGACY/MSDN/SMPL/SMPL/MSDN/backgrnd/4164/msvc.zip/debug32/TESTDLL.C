#define STRICT
#include <windows.h>
#include <commdlg.h>

#define SMF_SHOWDIALOG 0x00000001
#define SMF_COMPRESSFILE 0x00000002
#define SMF_NOMESSAGES 0x00000004



// from DBSYNC32.DLL
int WINAPI ApplyTransactionFile(LPCSTR lpcstrFileName, LPCSTR lpcstrDSN, BOOL bSaveLocalCopy);

int WINAPI DBSyncFileSend(LPSTR lpszMessageType, LPSTR lpszSubject, 
	LPSTR lpszMessageText, LPSTR lpszRecipient, LPSTR lpszFileName, LONG lFlags);

// local
BOOL GetDBXFileName(LPSTR szDBXFile, int nBufSize);

HINSTANCE g_hInst;

int PASCAL WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{	
	int rc;
	char szDbxFile[256];

	//avoid compiler warnings
	g_hInst = hInstance;
	hPrevInstance = hPrevInstance;
	lpCmdLine = lpCmdLine;
	nCmdShow = nCmdShow;
	
	
	if(FALSE == GetDBXFileName(szDbxFile, sizeof(szDbxFile)))
		return 0;

	rc = 0;
	
	
	ApplyTransactionFile(szDbxFile, "DBSYNC_SQL", TRUE);
		
	
	return (0);
}


BOOL GetDBXFileName(LPSTR szDBXFile, int nBufSize)
{
	OPENFILENAME of;

	memset(&of, 0, sizeof(OPENFILENAME));
	lstrcpy(szDBXFile, "");

	of.lStructSize = sizeof(OPENFILENAME);
    of.hwndOwner = GetActiveWindow();
    of.hInstance = g_hInst;
    of.lpstrFilter = ".DBX files (*.dbx)\0*.dbx\0";
    of.nFilterIndex= 1;
    of.lpstrFile = szDBXFile;
    of.nMaxFile = nBufSize;
    of.lpstrTitle = "DBSync Debug";
    of.Flags = OFN_HIDEREADONLY | OFN_FILEMUSTEXIST;
    
	return GetOpenFileName(&of);

}
