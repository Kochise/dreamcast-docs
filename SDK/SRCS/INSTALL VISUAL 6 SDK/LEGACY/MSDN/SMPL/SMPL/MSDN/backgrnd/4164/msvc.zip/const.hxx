//NON-localizable strings
static const char BASED_CODE SZ_INIFILE[] = "DBSYNC.INI";

//message types used by the Command() function
static const char BASED_CODE SZ_DBSYNC_MSGTYPE[] = "IPM.DBSync.DBSync";
static const char BASED_CODE SZ_DBSYNCTOCORP_MSGTYPE[] = "IPM.DBSync.DBSyncToCorp";
static const char BASED_CODE SZ_DBSYNCCONFIRM_MSGTYPE[] = "IPM.DBSync.DBSyncConfirm";
static const char BASED_CODE SZ_DBSYNC_CONFIRMSUBJECT[] = "DBSyncConfirm";

//user/password for the automatic sync
static const char BASED_CODE SZ_DBSYNC_UID[] = "UID=dbsync";
static const char BASED_CODE SZ_DBSYNC_PWD[] = "PWD=dbsync";

//.INI file settings for the remote users
static const char BASED_CODE SZ_INISEC_ATTACHEDDATA[] = "AttachedData";
static const char BASED_CODE SZ_INIKEY_DATADB[] = "DataDB";

// .INI file settings for the data source to be updated
static const char BASED_CODE SZ_INISEC_DBSYNC[] = "DBSync";
static const char BASED_CODE SZ_INIKEY_SHOWERRORMESSAGES[] = "ShowErrorMessages";
static const char BASED_CODE SZ_INIKEY_DBSYNCLOCALCACHE[] = "LocalStoragePath";
static const char BASED_CODE SZ_INIKEY_DBSYNCDSN[] = "DSNRemote";
static const char BASED_CODE SZ_INIKEY_DBSYNCDSNTOCORP[] = "DSNToCorp";
static const char BASED_CODE SZ_INIKEY_DBSYNCDATABASENAME[] = "SQLDatabaseName";

//name of the local log file (for confimations)
static const char BASED_CODE SZ_DBSYNCCONFIRMEDLOG[] = "dbxconf.log";

#define MAX_SQL_STMT_SIZE 16384		//maximum size of any one SQL statement