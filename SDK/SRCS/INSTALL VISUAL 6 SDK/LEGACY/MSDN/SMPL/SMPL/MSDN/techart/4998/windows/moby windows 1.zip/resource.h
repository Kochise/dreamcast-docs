//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by moby.rc
//
#define IDB_AHAB                        102
#define IDB_SEA                         103
#define IDB_WAKE                        104
#define IDB_MOBY                        105
#define IDB_SPOUT                       106
#define IDB_CLOUD                       107
#define IDD_DIALOG1                     108
#define IDD_SETTINGS_DLG                108
#define IDC_APP_REALTIME                1001
#define IDC_APP_HIGH                    1002
#define IDC_APP_NORMAL                  1003
#define IDC_APP_IDLE                    1004
#define IDC_THREAD_CRITICAL             1006
#define IDC_THREAD_HIGHEST              1007
#define IDC_THREAD_ABOVE                1008
#define IDC_THREAD_NORMAL               1009
#define IDC_THREAD_BELOW                1010
#define IDC_THREAD_LOWEST               1011
#define IDC_THREAD_IDLE                 1012
#define IDC_THREAD_CRITICAL2            1013
#define IDC_THREAD_HIGHEST2             1014
#define IDC_THREAD_ABOVE2               1015
#define IDC_THREAD_NORMAL2              1016
#define IDC_THREAD_BELOW2               1017
#define IDC_THREAD_LOWEST2              1018
#define IDC_THREAD_IDLE2                1019
#define ID_FILE_EXIT                    40002
#define ID_VIEW_SETTINGS                40005
#define ID_PRIORITIES                   40005
#define ID_FILE_NEWGAME                 40006
#define ID_TIMERS                       40007

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        111
#define _APS_NEXT_COMMAND_VALUE         40008
#define _APS_NEXT_CONTROL_VALUE         1016
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
