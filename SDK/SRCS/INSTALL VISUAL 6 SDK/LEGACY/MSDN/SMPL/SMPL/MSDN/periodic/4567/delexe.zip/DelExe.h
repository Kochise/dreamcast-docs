/******************************************************************************
Module name: DelExe.h
Written by:  Jeffrey Richter
Note:        This function works on Windows 95 but does NOT work on Windows NT.
******************************************************************************/


VOID WINAPI DeleteExecutable (DWORD dwExitCode, BOOL fRemoveDir);


///////////////////////////////// End of File /////////////////////////////////
