/******************************************************************************
Module name: DelExeBF.h
Written by:  Jeffrey Richter
Note:        This function works on both Windows 95 and Windows NT.
******************************************************************************/


VOID WINAPI DeleteExecutableBF (void);


///////////////////////////////// End of File /////////////////////////////////
