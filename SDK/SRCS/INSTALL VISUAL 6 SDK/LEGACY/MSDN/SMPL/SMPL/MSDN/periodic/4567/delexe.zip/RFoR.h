/******************************************************************************
Module name: RFoR.h
Written by:  Jeffrey Richter
Note:        This function works on both Windows 95 and Windows NT.
******************************************************************************/


BOOL WINAPI ReplaceFileOnReboot (LPCTSTR pszExisting, LPCTSTR pszNew);


///////////////////////////////// End of File /////////////////////////////////
