#ifndef _TIF_H
#define _TIF_H

#include "Picture.h"

bool LoadTIF( const char* pszFilename, MMRGBA &mmrgba, unsigned long int dwFlags );



#endif //_TIF_H

