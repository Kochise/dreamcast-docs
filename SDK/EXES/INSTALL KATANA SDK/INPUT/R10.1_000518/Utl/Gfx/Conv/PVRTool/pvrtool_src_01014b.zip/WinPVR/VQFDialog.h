#ifndef _VQFDIALOG_H_
#define _VQFDIALOG_H_

BOOL CALLBACK DlgProc_VQFDialog( HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam );

#endif //_VQFDIALOG_H_

