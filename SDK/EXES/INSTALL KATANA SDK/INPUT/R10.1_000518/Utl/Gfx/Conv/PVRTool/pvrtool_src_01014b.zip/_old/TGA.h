#ifndef _TGA_H
#define _TGA_H

#include "Picture.h"

bool LoadTGA( const char* pszFilename, MMRGBA &mmrgba, unsigned long int dwFlags );



#endif //_TGA_H

