#ifndef _BMP_H_
#define _BMP_H_

#include "Picture.h"

bool LoadBMP( const char* pszFilename, MMRGBA &mmrgba, unsigned long int dwFlags );



#endif //_BMP_H_