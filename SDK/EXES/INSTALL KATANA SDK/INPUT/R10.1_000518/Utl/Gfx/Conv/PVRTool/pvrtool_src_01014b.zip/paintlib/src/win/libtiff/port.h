
/* libtiff likes this file to be around.

 I like it as an excuse to write things you aren't really interested in. */
#define yadayadayada
/*
/--------------------------------------------------------------------
|
|      $log$
|
--------------------------------------------------------------------
*/
