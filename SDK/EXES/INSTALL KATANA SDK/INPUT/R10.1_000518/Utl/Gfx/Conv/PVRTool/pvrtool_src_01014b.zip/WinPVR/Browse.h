#ifndef _BROWSE_H
#define _BROWSE_H

extern BOOL InitBrowser();
extern BOOL Browse( const char* pszFolder = NULL );
extern void CleanupBrowser();

#endif //_BROWSE_H
